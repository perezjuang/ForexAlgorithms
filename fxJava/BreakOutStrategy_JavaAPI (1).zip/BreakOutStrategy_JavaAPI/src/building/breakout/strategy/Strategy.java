package building.breakout.strategy;

import java.util.List;

import pulling.historical.prices.breakout.CandleStick;

public interface Strategy {

		StrategyResult runStrategy(List<CandleStick> candleStickList);

}
