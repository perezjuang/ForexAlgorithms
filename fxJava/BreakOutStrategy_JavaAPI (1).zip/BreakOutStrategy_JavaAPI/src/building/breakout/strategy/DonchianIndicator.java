package building.breakout.strategy;

public class DonchianIndicator {
		
	public Double calculateDonchianIndicator(Double sumOfHighs, Double sumOfLows) {
		double donchianChannel = (sumOfHighs + sumOfLows)/2;
		return donchianChannel;
	}
}
