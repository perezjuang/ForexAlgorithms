package building.strategy.meanReversion;

import java.util.List;

import pulling.historical.data.meanReversion.CandleStick;

public interface Strategy {
		
	StrategyResult runStrategy(List<CandleStick> candleStickList);
}
