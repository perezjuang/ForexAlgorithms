package building.strategy.meanReversion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import com.fxcm.external.api.transport.sso.SSOAuthenticator;
import com.fxcm.fix.Instrument;
import com.fxcm.fix.UTCDate;
import com.fxcm.fix.UTCTimeOnly;

import building.strategy.meanReversion.MeanReversionStrategy;
import pulling.historical.data.meanReversion.HistoryMiner;
import pulling.historical.data.meanReversion.Utilities;
import pulling.historical.data.meanReversion.CandleStick;

public class SampleClass {
	public static void main(String[] args){
		UTCDate startDate;
		UTCTimeOnly startTime;
		int duration = 21;
		List<CandleStick> candleSticksList = new ArrayList<>();
		Instrument asset = new Instrument("EUR/USD");
		Calendar instance = Calendar.getInstance();
		instance.roll(Calendar.DAY_OF_YEAR, -20);
		startDate = new UTCDate(instance.getTime());
		startTime = new UTCTimeOnly(instance.getTime());

		try{
			HistoryMiner miner = new HistoryMiner("D25611997", "6925", "Demo", startDate, startTime, asset);
			miner.login(miner,miner);
			while(miner.stillMining) {
				Thread.sleep(1000);
			}
			Thread.sleep(1000);
			miner.logout(miner,miner);
			miner.convertHistoricalRatesToCandleSticks();
			miner.displayHistory();
			candleSticksList = miner.candleStickList;

//			for (int i = 0; i < candleSticksList.size(); i++) {
//				System.out.println(i + "Outer LOOOPP Uppper");
//				double sumOfMovingAverages = 0;
//				double sumOfMovingAverages2 = 0;
//				for (int j = 0; j < 20; j++) {
//					sumOfMovingAverages = candleSticksList.get(j).getCloseBid();
//					System.out.println(sumOfMovingAverages + " and the period is: " + "20");
//				}
//
//				for (int k = 0; k < 50; k++) {
//					sumOfMovingAverages2 = candleSticksList.get(k).getCloseBid();
//					System.out.println(sumOfMovingAverages2 + " and the period is: " + "50");
//				}
//				System.out.println(i + "Outer LOOOPP Lower");
//			}
//			System.out.println(candleSticksList.get(i).getCloseBid());
//			System.out.println("AND");
//			System.out.println();
//			System.out.println(candleSticksList.get(j).getCloseBid());
			List<Double> shliokavica = new ArrayList<>();
			double slowSMA = 0;
			
			for (int i = 0; i < candleSticksList.size(); i++) {
				double sumOfAllSlowBids = 0; 
				List<Double> listOfAllSlowBids = new ArrayList<>();
				for (int j = 0; j < 20; j++) {
					listOfAllSlowBids.add(candleSticksList.get(j).getCloseBid());
					sumOfAllSlowBids = Utilities.addAllNumbers(listOfAllSlowBids)/20;
				}
				shliokavica = listOfAllSlowBids;
				slowSMA = sumOfAllSlowBids;
				
			}
			System.out.println("listOfAllSlowBids" + shliokavica + "Outside both of the fucking loops");
			System.out.println("sumOfAllSlowBids" + slowSMA + "Outside both of the fucking loops\n");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}