package building.strategy.meanReversion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class TestingLoops {

	public static void main(String[] args) {


		List<Integer> list1 = new ArrayList<>();
		List<Integer> list2 = new ArrayList<>();
		List<Integer> list3 = new ArrayList<>();
		for (int j = 1; j < 11; j++) {
			list1.add(j);
		}
		for (int k = 11; k < 21; k++) {
			list2.add(k);
		}
		for (int j = 1; j < 31; j++) {
			list3.add(j);
		}
//		System.out.println(Arrays.asList(list1));
//		System.out.println(Arrays.asList(list2));
//		System.out.println(Arrays.asList(list3));
		
		
		for (int i = 0; i < list3.size(); i++) {
			for (int j = 0; j < list1.size(); j++) {
				System.out.println(i + "AND" + j);
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}
}
