package pulling.historical.data.meanReversion;

public class CandleStick {

	private String date;
	private double open;
	private double low;
	private double high;
	private double closeBid;
	private double closeAsk;
	private double slowSMA;
	private double fastSMA;
	public double averageSMA;
	
	public CandleStick(String date, double open, double low, double high, double closeBid, double closeAsk) {
		super();
		this.date = date;
		this.open = open;
		this.low = low;
		this.high = high;
		this.closeBid = closeBid;
		this.closeAsk = closeAsk;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public double getOpen() {
		return open;
	}

	public void setOpen(double open) {
		this.open = open;
	}

	public double getLow() {
		return low;
	}

	public void setLow(double low) {
		this.low = low;
	}

	public double getHigh() {
		return high;
	}

	public void setHigh(double high) {
		this.high = high;
	}

	public double getCloseBid() {
		return closeBid;
	}

	public void setCloseBid(double closeBid) {
		this.closeBid = closeBid;
	}

	public double getCloseAsk() {
		return closeAsk;
	}

	public void setCloseAsk(double closeAsk) {
		this.closeAsk = closeAsk;
	}

	public double getSlowSMA() {
		return slowSMA;
	}

	public void setSlowSMA(double slowSMA) {
		this.slowSMA = slowSMA;
	}

	public double getFastSMA() {
		return fastSMA;
	}

	public void setFastSMA(double fastSMA) {
		this.fastSMA = fastSMA;
	}

	public double getAverageSMA() {
		return averageSMA;
	}

	public void setAverageSMA(double averageSMA) {
		this.averageSMA = averageSMA;
	}
}