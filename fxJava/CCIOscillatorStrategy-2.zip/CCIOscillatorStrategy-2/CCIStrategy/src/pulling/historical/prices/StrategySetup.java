package pulling.historical.prices;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import building.cci_based.strategy.CCIIndicatorStrategy;
import building.cci_based.strategy.Strategy;
import building.cci_based.strategy.StrategyResult;

public class StrategySetup {
	
	public void adjustStrategySettings(double stopLoss, double takeProfit, int bottomLimitOfTheIndicator, List<CandleStick> candleSticksList, List <StrategyResult> strategySummary) {
		for (double i = stopLoss; i < stopLoss+0.001; i+=0.0001) {
			for (double j = takeProfit; j < takeProfit+0.003; j+=0.0005) {
				for (int k = bottomLimitOfTheIndicator; k <= bottomLimitOfTheIndicator+20; k+=5) {
					manageStrategyResults(strategySummary, candleSticksList, stopLoss, takeProfit, bottomLimitOfTheIndicator);
				}
			}
		}

		Collections.sort(strategySummary,new StrategyResult());
	}
	
	public void manageStrategyResults(List <StrategyResult> strategySummary, List<CandleStick> candleSticksList, double stopLoss, double takeProfit, int bottomLimitOfTheIndicator) {
		Strategy cciIndicator = new CCIIndicatorStrategy(stopLoss, takeProfit, bottomLimitOfTheIndicator);
		StrategyResult sr = ((CCIIndicatorStrategy) cciIndicator).runStrategy(candleSticksList);
		strategySummary.add(sr);
	}
	
	
}
