package pulling.historical.prices;

public class CandleStick {

	private String date;
	private double open;
	private double low;
	private double high;
	private double closeBid;
	private double closeAsk;
	private double cci;

	public CandleStick(String date, double open, double low, double high, double closeBid,
			double closeAsk) {
		this.date = date;
		this.open = open;
		this.low = low;
		this.high = high;
		this.closeBid = closeBid;
		this.closeAsk = closeAsk;
	}
	public CandleStick(String date, double open, double low, double high, double closeBid) {
		this.date = date;
		this.open = open;
		this.low = low;
		this.high = high;
		this.closeBid = closeBid;
	}
	@Override
	public String toString() {
		return "CandleStick [date=" + date + ", open=" + open + ", low=" + low + ", high=" + high + ", closeBid="
				+ closeBid + ", closeAsk=" + closeAsk + ", cci=" + cci + "]";
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getOpen() {
		return open;
	}
	public void setOpen(double open) {
		this.open = open;
	}
	public double getLow() {
		return low;
	}
	public void setLow(double low) {
		this.low = low;
	}
	public double getHigh() {
		return high;
	}
	public void setHigh(double high) {
		this.high = high;
	}
	public double getCloseBid() {
		return closeBid;
	}
	public void setCloseBid(double closeBid) {
		this.closeBid = closeBid;
	}
	public double getCloseAsk() {
		return closeAsk;
	}
	public void setCloseAsk(double closeAsk) {
		this.closeAsk = closeAsk;
	}
	public double getCCI() {
		return cci;
	}
	public void setCCI(double cci) {
		this.cci = cci;
	}

}