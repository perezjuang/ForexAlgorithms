package pulling.historical.prices;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.TreeSet;

import com.fxcm.external.api.transport.FXCMLoginProperties;
import com.fxcm.external.api.transport.GatewayFactory;
import com.fxcm.external.api.transport.IGateway;
import com.fxcm.external.api.transport.listeners.IGenericMessageListener;
import com.fxcm.external.api.transport.listeners.IStatusMessageListener;
import com.fxcm.fix.FXCMTimingIntervalFactory;
import com.fxcm.fix.IFixDefs;
import com.fxcm.fix.Instrument;
import com.fxcm.fix.SubscriptionRequestTypeFactory;
import com.fxcm.fix.UTCDate;
import com.fxcm.fix.UTCTimeOnly;
import com.fxcm.fix.UTCTimestamp;
import com.fxcm.fix.entity.MarketDataSnapshot;
import com.fxcm.fix.pretrade.MarketDataRequest;
import com.fxcm.fix.pretrade.MarketDataRequestReject;
import com.fxcm.fix.pretrade.TradingSessionStatus;
import com.fxcm.messaging.ISessionStatus;
import com.fxcm.messaging.ITransportable;


public class HistoryMiner implements IGenericMessageListener, IStatusMessageListener{

	private static final String server = "http://www.fxcorporate.com/Hosts.jsp";
	private Instrument asset;
	private static FXCMLoginProperties login;
	private static IGateway gateway;
	private static String currentRequest;
	private final HashMap<UTCDate, MarketDataSnapshot> historicalRates = new HashMap<>();
	private int dataCounter=0;
	public List<CandleStick> candleStickList = new ArrayList<CandleStick>();
	private UTCDate startDate;
	private UTCTimeOnly startTime;
	private UTCTimestamp openTimestamp;
	public boolean stillMining=true;
	static IGenericMessageListener genericMessageListener;
	static IStatusMessageListener statusMessageListener;

	public HistoryMiner(String username, String password, String terminal, UTCDate startDate, UTCTimeOnly startTime, Instrument asset) {
		this.asset=asset;
		this.startDate = startDate;
		this.startTime = startTime;
		//create a local LoginProperty
		this.login = new FXCMLoginProperties(username, password, terminal, server);
	}

	public boolean login(IGenericMessageListener genericMessageListener, IStatusMessageListener statusMessageListener) {

		try {
			if(gateway == null)
				gateway = GatewayFactory.createGateway();

			gateway.registerGenericMessageListener(genericMessageListener);
			gateway.registerStatusMessageListener(statusMessageListener);

			if(!gateway.isConnected())
				gateway.login(this.login);

			currentRequest = gateway.requestTradingSessionStatus();

			return true;
		}catch(Exception e) {
			e.printStackTrace();
		}

		return false;
	}


	@Override
	public void messageArrived(ISessionStatus status) {
		if(status.getStatusCode() == ISessionStatus.STATUSCODE_ERROR ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_DISCONNECTING ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_CONNECTING ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_CONNECTED ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_CRITICAL_ERROR ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_EXPIRED ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_LOGGINGIN ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_LOGGEDIN ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_PROCESSING ||
				status.getStatusCode() == ISessionStatus.STATUSCODE_DISCONNECTED)
		{
			//display status message
			System.out.println("\t\t" + status.getStatusMessage());
		}
	}

	@Override
	public void messageArrived(ITransportable message) {
		try {
			if(message instanceof MarketDataSnapshot) messageArrived((MarketDataSnapshot)message);
			if(message instanceof MarketDataRequestReject) messageArrived((MarketDataRequestReject)message);
			else if(message instanceof TradingSessionStatus) messageArrived((TradingSessionStatus)message);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void messageArrived(TradingSessionStatus tss){
		if(currentRequest.equals(tss.getRequestID())) {
			MarketDataRequest mdr = new MarketDataRequest();
			mdr.setSubscriptionRequestType(SubscriptionRequestTypeFactory.SNAPSHOT);
			mdr.setResponseFormat(IFixDefs.MSGTYPE_FXCMRESPONSE);
			mdr.setFXCMTimingInterval(FXCMTimingIntervalFactory.MIN30);
			mdr.setFXCMStartDate(startDate);
			mdr.setFXCMStartTime(startTime);
			mdr.addRelatedSymbol(asset);
			currentRequest=sendRequest(mdr);
		}
	}

	private String sendRequest(MarketDataRequest request) {

		try {
			currentRequest = gateway.sendMessage(request);

			return currentRequest;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void logout(IGenericMessageListener genericMessageListener, IStatusMessageListener statusMessageListener) {
		gateway.logout();
		gateway.removeGenericMessageListener(genericMessageListener);
		gateway.removeStatusMessageListener(statusMessageListener);
	}

	public void messageArrived(MarketDataSnapshot mds) {
		if(mds.getRequestID() != null && mds.getRequestID().equals(currentRequest)){
			historicalRates.put(mds.getDate(), mds);
		}
		if (mds.getRequestID() != null) {
			dataCounter++;
			if(openTimestamp == null) {
				openTimestamp = mds.getOpenTimestamp();
				System.out.println("first\t= " + mds.getOpenTimestamp() + " = " + mds.getRequestID());
			}
			if(mds.getFXCMContinuousFlag() == IFixDefs.FXCMCONTINUOUS_END) {
				System.out.println("last\t= " + mds.getOpenTimestamp() + " = " + mds.getRequestID() + "\n");
				MarketDataRequest mdr = new MarketDataRequest();
				mdr.setSubscriptionRequestType(SubscriptionRequestTypeFactory.SNAPSHOT);
				mdr.setResponseFormat(IFixDefs.MSGTYPE_FXCMRESPONSE);
				mdr.setFXCMTimingInterval(FXCMTimingIntervalFactory.MIN1);
				mdr.setFXCMStartDate(startDate);
				mdr.setFXCMStartTime(startTime);
				mdr.setFXCMEndDate(new UTCDate(openTimestamp));
				mdr.setFXCMEndTime(new UTCTimeOnly(openTimestamp));
				mdr.addRelatedSymbol(asset);

				Utilities.writeString("FXCMStartDate\t=  " + mdr.getFXCMStartDate());
				Utilities.writeString("FXCMStartTime\t= " + mdr.getFXCMStartTime());
				Utilities.writeString("FXCMEndDate\t\t= " + mdr.getFXCMEndDate());
				Utilities.writeString("FXCMEndTime\t\t= " + mdr.getFXCMEndTime());
				Utilities.writeString("-----------------------\ntotal mds received = " + dataCounter+"\n");
				if(!(mds.getOpenTimestamp().equals(openTimestamp))) {
					currentRequest = sendRequest(mdr);
					openTimestamp = null;
				}else{
					stillMining=false;
					Utilities.writeString("mining over....");
				}
			}
		}
	}
	
	public void messageArrived(MarketDataRequestReject mdrr) {
		Utilities.writeString("Historical data rejected;" + mdrr.getMDReqRejReason());
		stillMining=false;
	}

	public void convertHistoricalRatesToCandleSticks() {
		SortedSet<UTCDate> dateList = new TreeSet<>(historicalRates.keySet());
		SimpleDateFormat sdf= new SimpleDateFormat("dd.MM.yyyy HH:mm");
		sdf.setTimeZone(TimeZone.getTimeZone("Europe/London"));

		for(UTCDate date : dateList) {

			MarketDataSnapshot candleData;

			candleData = historicalRates.get(date);
			Date candleDate = date.toDate();
			String sdfDate = sdf.format(candleDate);
			double open = candleData.getBidOpen();
			double low = candleData.getBidLow();
			double high = candleData.getAskHigh();
			double closeBid = candleData.getBidClose();
			double closeAsk = candleData.getAskClose();


			CandleStick candleStick = new CandleStick(sdfDate, open, low, high, closeBid, closeAsk);
			candleStickList.add(candleStick);
		}
	}
	
	public HashMap<UTCDate, MarketDataSnapshot> getHistoricalRates(){
		return historicalRates;
	}
	
	public List<CandleStick> getCandleStickList(){
		return candleStickList;
	}
	
	
}
