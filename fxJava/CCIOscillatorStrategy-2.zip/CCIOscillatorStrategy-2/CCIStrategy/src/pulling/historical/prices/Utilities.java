package pulling.historical.prices;

public class Utilities { 
	
	public static void writeString(String text) {
		System.out.println(text);
	}
	
	
}
