package backtesting.cci_based.strategy;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import com.fxcm.fix.Instrument;
import com.fxcm.fix.UTCDate;
import com.fxcm.fix.UTCTimeOnly;

import building.cci_based.strategy.CCIIndicatorStrategy;
import building.cci_based.strategy.Strategy;
import building.cci_based.strategy.StrategyResult;
import pulling.historical.prices.CandleStick;
import pulling.historical.prices.DisplayResults;
import pulling.historical.prices.HistoryMiner;
import pulling.historical.prices.RatesToCandlesticks;
import pulling.historical.prices.StrategySetup;
import pulling.historical.prices.Utilities;

public class TesterClass {


	public static void main(String[] args) {

		List <CandleStick> candleSticksList = null;
		double stopLoss=0.001;
		double takeProfit=0.003;
		int bottomCCI=-120; 
		double avergeProfit;
		List <StrategyResult> strategySummary = new ArrayList<StrategyResult>();
		UTCDate startDate;
		UTCTimeOnly startTime;
		Instrument asset = new Instrument("EUR/USD");
		RatesToCandlesticks rtc = new RatesToCandlesticks();
		DisplayResults ds = new DisplayResults();
		StrategySetup ss = new StrategySetup();
		Calendar instance = Calendar.getInstance();
		instance.roll(Calendar.DAY_OF_YEAR, -20);
		startDate = new UTCDate(instance.getTime());
		startTime = new UTCTimeOnly(instance.getTime());
		double representResults = 0; 
		String percentSign = "%";
		try{
			HistoryMiner miner = new HistoryMiner("D25611997", "6925", "Demo", startDate,startTime, asset);
			miner.login(miner,miner);
			while(miner.stillMining) {
				Thread.sleep(1000);
			}
			Thread.sleep(1000);
			miner.logout(miner,miner);
			candleSticksList = miner.getCandleStickList();
			rtc.convertHistoricalRatesToCandleSticks(miner.getHistoricalRates(), candleSticksList);
			ds.displayHistory(candleSticksList);
			CCIIndicatorStrategy.calculateCciForDataSet(candleSticksList, 20);
			ss.adjustStrategySettings(stopLoss, takeProfit, bottomCCI, candleSticksList, strategySummary);
			avergeProfit=StrategyResult.calculateAvgStrategyProfit(strategySummary);
			Utilities.writeString("Average profit=> "+(double)Math.round(10000*avergeProfit)/100+percentSign);
			ds.displayBestWinningsFromBacktesting(strategySummary);
			ds.displayWorstWinningsFromBacktesting(strategySummary);
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
