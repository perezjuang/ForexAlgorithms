package building.cci_based.strategy;

import java.util.List;

import pulling.historical.prices.CandleStick;

public class MeanDeviationIndicator {

	protected double calculateMeanDeviation(double average, List<Double> listOfPrices, int duration) {
		double sumOfDeviations = 0; 
		
		for (int j = 0; j < duration; j++) {
			 sumOfDeviations += Math.abs(average-listOfPrices.get(j));
			double meanDeviation = sumOfDeviations/duration;
			return meanDeviation;
		}
		return 0;
	}
}
