package building.cci_based.strategy;

import java.util.List;

import pulling.historical.prices.CandleStick;

public interface Strategy {

		StrategyResult runStrategy(List<CandleStick> candleStickList);
}
