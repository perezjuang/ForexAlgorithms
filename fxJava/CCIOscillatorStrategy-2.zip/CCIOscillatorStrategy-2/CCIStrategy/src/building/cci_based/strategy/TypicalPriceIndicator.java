package building.cci_based.strategy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import com.fxcm.fix.Instrument;
import com.fxcm.fix.UTCDate;
import com.fxcm.fix.UTCTimeOnly;

import pulling.historical.prices.CandleStick;
import pulling.historical.prices.HistoryMiner;

public class TypicalPriceIndicator {

	List<CandleStick> candleSticksList;
	double typicalPrice;

    public TypicalPriceIndicator(List<CandleStick> candleSticksList, double typicalPrice) {
		this.candleSticksList = candleSticksList;
		this.typicalPrice = typicalPrice;
	}
		protected double calculateTypicalPrice(List<CandleStick> candleSticksList, int index) {
		    	double high = 0;
				double low = 0 ; 
				double closeBid = 0;
			 for (int j = 0; j < index; j++) {
					high = candleSticksList.get(j).getHigh();
					low  = candleSticksList.get(j).getLow();
					closeBid = candleSticksList.get(j).getCloseBid(); 
					typicalPrice = (high + low + closeBid)/3;
					return typicalPrice;
			 }	
			 return 0;
		    }
}