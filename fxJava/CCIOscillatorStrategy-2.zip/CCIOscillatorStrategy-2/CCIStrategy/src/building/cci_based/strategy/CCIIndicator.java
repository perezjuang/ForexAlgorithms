package building.cci_based.strategy;

import java.util.List;

public class CCIIndicator {

	protected double calculateCCI(List<Double> listOfTypicalPrices, double averageOfTypicalPrices, double constant, double meanDeviationOfTypicalPrices, int duration) {
		double cci = 0;
		for (int k = 0; k < duration; k++) {
			cci = (listOfTypicalPrices.get(k) - averageOfTypicalPrices/(constant*meanDeviationOfTypicalPrices));
			return cci;
		}
		return 0;
		
		
	}
	
	
}
