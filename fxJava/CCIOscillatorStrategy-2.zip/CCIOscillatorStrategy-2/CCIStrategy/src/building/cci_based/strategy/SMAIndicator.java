package building.cci_based.strategy;

import java.util.List;

import javax.swing.text.StyledEditorKit.ForegroundAction;

import pulling.historical.prices.CandleStick;

public class SMAIndicator {
   
	List<Double> listOfPrices;
	int duration;
		
	protected Double calculateSMA(List<Double> listOfPrices, int duration){
		double smaOfTypicalPrices = (listOfPrices.stream().mapToDouble(Double::doubleValue).sum())/duration;
		return smaOfTypicalPrices;
	}
}
